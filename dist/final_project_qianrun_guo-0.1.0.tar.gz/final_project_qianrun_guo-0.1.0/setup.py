# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['final_project_qianrun_guo',
 'final_project_qianrun_guo.docs',
 'final_project_qianrun_guo.final_project_qianrun_guo',
 'final_project_qianrun_guo.tests']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.1.5,<2.0.0', 'requests>=2.25.1,<3.0.0']

setup_kwargs = {
    'name': 'final-project-qianrun-guo',
    'version': '0.1.0',
    'description': "Python Package that interacts with a financial API and extracts financial statements of user's choice of company. Moreover, this package contians functions to calculate essential financial ratios for business valuation.",
    'long_description': None,
    'author': 'Qianrun Guo',
    'author_email': 'qg2196@columbia.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
