from final_project import __version__
from final_project import final_project

def test_version():
    assert __version__ == '0.1.0'