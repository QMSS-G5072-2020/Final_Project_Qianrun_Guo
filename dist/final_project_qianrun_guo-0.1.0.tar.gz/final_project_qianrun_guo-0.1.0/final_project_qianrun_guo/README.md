# final_project 

![](https://github.com/qrguo-0416/final_project/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/qrguo-0416/final_project/branch/main/graph/badge.svg)](https://codecov.io/gh/qrguo-0416/final_project) ![Release](https://github.com/qrguo-0416/final_project/workflows/Release/badge.svg) [![Documentation Status](https://readthedocs.org/projects/final_project/badge/?version=latest)](https://final_project.readthedocs.io/en/latest/?badge=latest)

Python Package that interacts with a financial API and extracts financial statements of user's choice of company. Moreover, this package contians functions to calculate essential financial ratios for business valuation.

## Installation

```bash
$ pip install -i https://test.pypi.org/simple/ final_project
```

## Features

- TODO

## Dependencies

- TODO

## Usage

- TODO

## Documentation

The official documentation is hosted on Read the Docs: https://final_project.readthedocs.io/en/latest/

## Contributors

We welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/qrguo-0416/final_project/graphs/contributors).

### Credits

This package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).
